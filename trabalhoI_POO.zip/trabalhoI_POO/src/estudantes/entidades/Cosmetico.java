package trabalhoI_POO.src.estudantes.entidades;

public class Cosmetico extends CuidadosPessoais {
    // Atributos da classe 
    private char tipoDePele;

    // Construtor de Cosmetico que chama o construtor da classe Produto
    public Cosmetico(int codigo, String nome, String fabricante, int peso, long validade, String fragrancia, char tipoDePele) {
        super(codigo, nome, fabricante, peso, validade, fragrancia);
        this.tipoDePele = tipoDePele;
    }

    // Getters para acessar atributos privados
    public char getTipoDePele() {
        return tipoDePele;
    }

    // Método toString para armazenamento dos dados em String
    @Override
    public String toString() {
        return super.toString() + ", tipoDePele: " + tipoDePele;
    }

    // Método hashCode para registro em INT
    @Override
    public int hashCode() {
        int result = super.hashCode(); // Chama o hashCode da superclasse Produto
        result = 31 * result + (int) tipoDePele; // Adiciona tipoDePele ao cálculo de hashCode
        return result;
    }

    // Método equals para comparação da estrutura dos objetos
    @Override
    public boolean equals(Object outro) {
        // Verifica se o objeto passado é nulo ou de outra classe
        if (outro == null) {
            return false;
        }
        // Verifica se é igual ao próprio objeto
        if (this == outro) {
            return true;
        }
        // Objetos de classes diferentes nunca são iguais
        if(this.getClass() != outro.getClass()){
            return false;
        }
        // Chama o equals da superclasse Produto
        if (!super.equals(outro)) {
            return false;
        }
        // Conversão explícita para acessar os atributos do outro objeto
        Cosmetico outroCosmetico = (Cosmetico) outro;
        // Compara o atributo 
        if(this.tipoDePele == outroCosmetico.tipoDePele){
            return true;
        }else{
            return false;
        }
    }
}

//  * 4) ter um JavaDoc útil e completo. PENDENTE

